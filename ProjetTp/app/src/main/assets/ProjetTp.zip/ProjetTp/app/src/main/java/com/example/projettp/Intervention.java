package com.example.projettp;

import androidx.appcompat.app.AppCompatActivity;


import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;

public class Intervention extends AppCompatActivity {

    Button date;
    ListView list;
ImageButton but;
    private static final String urlm ="http://127.0.0.1/empdata.json";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_intervention);
list=findViewById (R.id.Listview);
but=findViewById (R.id.button);
final ArrayList<Data>arrayList=new ArrayList<> ();



final MyListAdapter myListAdapter=new MyListAdapter (this,R.layout.list, arrayList);
arrayList.add (new Data ("s1","adresse1"));
list.setAdapter (myListAdapter);

        but.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                arrayList.add(new Data ("so1","ad1"));
                myListAdapter.notifyDataSetChanged();
                Toast.makeText (getApplicationContext (),"nouvelle intervention ajouter",Toast.LENGTH_SHORT).show ();
            }
        });


        date = findViewById(R.id.date);
        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {




            final Calendar c = Calendar.getInstance();
                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);
                int day = c.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog picker = new DatePickerDialog(Intervention.this, new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                        date.setText(day+"-"+(month+1)+"-"+year);
                    }
                }, year, month,day);
                picker.show();
            }
        });


    }


}