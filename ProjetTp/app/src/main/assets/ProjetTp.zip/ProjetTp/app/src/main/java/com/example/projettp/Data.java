package com.example.projettp;

public class Data {
    String societe;
    String adress;

    public Data(String societe, String adress) {
        this.societe = societe;
        this.adress = adress;
    }

    public String getSociete() {
        return societe;
    }

    public void setSociete(String societe) {
        this.societe = societe;
    }

    public String getAdress() {
        return adress;
    }

    public void setAdress(String adress) {
        this.adress = adress;
    }
}
