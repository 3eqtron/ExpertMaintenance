package com.example.projettp;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class MyListAdapter extends ArrayAdapter<Data> {
private Context mcontext;
private int mRessource;

    public MyListAdapter(@NonNull Context context, int resource, @NonNull ArrayList<Data> objects) {
        super (context, resource, objects);
        this.mcontext=context;
        this.mRessource=resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater layoutInflater=LayoutInflater.from (mcontext);
        convertView=layoutInflater.inflate (mRessource,parent,false);
        TextView textView=convertView.findViewById (R.id.societe_list);
        TextView textView1=convertView.findViewById (R.id.adress_list);
        textView.setText (getItem (position).getSociete ());
        textView1.setText (getItem (position).getAdress ());

        return convertView;
    }
}

